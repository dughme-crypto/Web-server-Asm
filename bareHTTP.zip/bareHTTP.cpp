#include <iostream>
#include <string>
#include <string_view>
#include <unordered_map>
#include <functional>
#include <vector>
#include <cstring>
#include <cerrno>
#include <cstdlib>

#include <sys/socket.h>
#include <sys/epoll.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>

static constexpr int    PORT        = 8080;
static constexpr int    BACKLOG     = 1024;
static constexpr int    MAX_EVENTS  = 1024;
static constexpr size_t BUF_SIZE    = 4096;

using Handler = std::function<void(int fd, std::string_view method, std::string_view path)>;

static std::unordered_map<std::string, Handler> routes;

static void set_nonblocking(int fd) {
    int flags = fcntl(fd, F_GETFL, 0);
    fcntl(fd, F_SETFL, flags | O_NONBLOCK);
}

static void send_response(int fd, int status, std::string_view status_text,
                          std::string_view content_type, std::string_view body) {
    char header[512];
    int hlen = snprintf(header, sizeof(header),
        "HTTP/1.1 %d %.*s\r\n"
        "Content-Type: %.*s\r\n"
        "Content-Length: %zu\r\n"
        "Connection: keep-alive\r\n"
        "\r\n",
        status,
        (int)status_text.size(), status_text.data(),
        (int)content_type.size(), content_type.data(),
        body.size()
    );

    struct iovec iov[2];
    iov[0].iov_base = header;
    iov[0].iov_len  = hlen;
    iov[1].iov_base = const_cast<char*>(body.data());
    iov[1].iov_len  = body.size();
    writev(fd, iov, 2);
}

static void send_200(int fd, std::string_view body, std::string_view ct = "text/html; charset=utf-8") {
    send_response(fd, 200, "OK", ct, body);
}

static void send_404(int fd) {
    send_response(fd, 404, "Not Found", "text/plain", "404 Not Found");
}

static void handle_client(int fd) {
    char buf[BUF_SIZE];
    ssize_t n = recv(fd, buf, sizeof(buf) - 1, 0);
    if (n <= 0) { close(fd); return; }
    buf[n] = '\0';

    std::string_view req(buf, n);

    auto line_end = req.find("\r\n");
    if (line_end == std::string_view::npos) { send_404(fd); return; }

    std::string_view req_line = req.substr(0, line_end);

    auto sp1 = req_line.find(' ');
    if (sp1 == std::string_view::npos) { send_404(fd); return; }

    auto sp2 = req_line.find(' ', sp1 + 1);
    if (sp2 == std::string_view::npos) { send_404(fd); return; }

    std::string_view method = req_line.substr(0, sp1);
    std::string_view path   = req_line.substr(sp1 + 1, sp2 - sp1 - 1);

    auto qmark = path.find('?');
    if (qmark != std::string_view::npos)
        path = path.substr(0, qmark);

    std::string path_str(path);
    auto it = routes.find(path_str);
    if (it != routes.end()) {
        it->second(fd, method, path);
    } else {
        send_404(fd);
    }
}

static int create_server_socket() {
    int fd = socket(AF_INET, SOCK_STREAM | SOCK_NONBLOCK, 0);
    if (fd < 0) { perror("socket"); exit(1); }

    int opt = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    setsockopt(fd, SOL_SOCKET, SO_REUSEPORT, &opt, sizeof(opt));
    setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &opt, sizeof(opt));

    sockaddr_in addr{};
    addr.sin_family      = AF_INET;
    addr.sin_port        = htons(PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(fd, (sockaddr*)&addr, sizeof(addr)) < 0) { perror("bind"); exit(1); }
    if (listen(fd, BACKLOG) < 0) { perror("listen"); exit(1); }

    return fd;
}

void GET(const std::string& path, Handler h) {
    routes[path] = std::move(h);
}

int main() {
    GET("/", [](int fd, std::string_view, std::string_view) {
        send_200(fd,
            "<!DOCTYPE html><html lang='en'><head>"
            "<meta charset='UTF-8'>"
            "<title>bareHTTP</title>"
            "<style>"
            ":root{--bg:#0a0a0f;--gold:#f0a500;--fg:#e8e0d0;--dim:#555}"
            "*{margin:0;padding:0;box-sizing:border-box}"
            "body{background:var(--bg);color:var(--fg);font-family:'Courier New',monospace;"
            "display:flex;align-items:center;justify-content:center;min-height:100vh}"
            ".grid{position:fixed;inset:0;"
            "background-image:linear-gradient(rgba(240,165,0,.04) 1px,transparent 1px),"
            "linear-gradient(90deg,rgba(240,165,0,.04) 1px,transparent 1px);"
            "background-size:40px 40px;pointer-events:none}"
            ".box{text-align:center;z-index:1;padding:3rem 2rem}"
            "h1{font-size:clamp(3rem,10vw,6rem);color:var(--gold);"
            "text-shadow:0 0 40px rgba(240,165,0,.5);border:3px solid var(--gold);"
            "display:inline-block;padding:.3em .7em;"
            "animation:flicker 4s infinite}"
            "p{margin-top:2rem;opacity:.8;line-height:1.9;max-width:480px;"
            "margin-left:auto;margin-right:auto}"
            ".badge{display:inline-block;margin-top:2rem;font-size:.7rem;"
            "letter-spacing:.2em;text-transform:uppercase;color:var(--dim);"
            "border:1px solid var(--dim);padding:.4em 1em}"
            "@keyframes flicker{0%,95%,100%{opacity:1}96%{opacity:.8}97%{opacity:1}98%{opacity:.6}99%{opacity:1}}"
            "</style></head><body>"
            "<div class='grid'></div>"
            "<div class='box'>"
            "<h1>bareHTTP</h1>"
            "<p>Welcome to this website, built using <strong>bareHTTP</strong>,<br>"
            "a webserver written in C++ with epoll.</p>"
            "<div class='badge'>HTTP/1.1 &nbsp;&#183;&nbsp; epoll &nbsp;&#183;&nbsp; C++ &nbsp;&#183;&nbsp; port 8080</div>"
            "</div></body></html>"
        );
    });

    GET("/ping", [](int fd, std::string_view, std::string_view) {
        send_200(fd, "pong", "text/plain");
    });

    GET("/json", [](int fd, std::string_view, std::string_view) {
        send_200(fd, R"({"status":"ok","server":"bareHTTP"})", "application/json");
    });

    int server_fd = create_server_socket();

    int epfd = epoll_create1(0);
    if (epfd < 0) { perror("epoll_create1"); exit(1); }

    epoll_event ev{};
    ev.events  = EPOLLIN;
    ev.data.fd = server_fd;
    epoll_ctl(epfd, EPOLL_CTL_ADD, server_fd, &ev);

    std::cout << "bareHTTP listening on port " << PORT << "...\n";
    std::cout << "Routes: GET /   GET /ping   GET /json\n";

    std::vector<epoll_event> events(MAX_EVENTS);

    while (true) {
        int n = epoll_wait(epfd, events.data(), MAX_EVENTS, -1);
        for (int i = 0; i < n; i++) {
            if (events[i].data.fd == server_fd) {
                while (true) {
                    int client_fd = accept4(server_fd, nullptr, nullptr, SOCK_NONBLOCK);
                    if (client_fd < 0) break;

                    int opt = 1;
                    setsockopt(client_fd, IPPROTO_TCP, TCP_NODELAY, &opt, sizeof(opt));

                    epoll_event cev{};
                    cev.events  = EPOLLIN | EPOLLET;
                    cev.data.fd = client_fd;
                    epoll_ctl(epfd, EPOLL_CTL_ADD, client_fd, &cev);
                }
            } else {
                int fd = events[i].data.fd;
                epoll_ctl(epfd, EPOLL_CTL_DEL, fd, nullptr);
                handle_client(fd);
                close(fd);
            }
        }
    }

    close(server_fd);
    close(epfd);
    return 0;
}
